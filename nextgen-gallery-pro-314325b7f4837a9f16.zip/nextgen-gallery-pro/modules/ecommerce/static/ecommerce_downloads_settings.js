(function($) {
    $('label.tooltip, span.tooltip').tooltip();
})(jQuery);