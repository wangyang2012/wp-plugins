jQuery(function() {
    Ngg_Store.set('ngg_pro_cart', {});
    Ngg_Store.save()
});