<td class='nggpl-quantity_field'>
    <input type='number' value='0' min='0'/>
</td>
<td class='nggpl-description_field'></td>
<td class='nggpl-price_field'></td>
<td class='nggpl-total_field'></td>