<tr id='tr_<?php print esc_attr("{$display_type_name}_{$name}"); ?>' class='nextgen_pro_lightbox_admin_header <?php print !empty($hidden) ? 'hidden' : ''; ?>'>
    <td><h3><?php echo $label; ?></h3></td>
    <td></td>
</tr>