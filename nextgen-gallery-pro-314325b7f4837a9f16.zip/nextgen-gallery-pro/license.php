<?php 

$license = '5dba74c1-aaee-4f6f-8054-57b3da1b4231';
