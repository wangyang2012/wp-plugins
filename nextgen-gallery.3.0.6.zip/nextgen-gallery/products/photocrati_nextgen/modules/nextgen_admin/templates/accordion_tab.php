<h3 class="accordion_tab" id="<?php echo esc_attr($id) ?>"><a href="#"><?php echo esc_html($title) ?></a></h3>
<div id="<?php echo esc_attr($id) ?>_content">
	<?php echo $content ?>
</div>